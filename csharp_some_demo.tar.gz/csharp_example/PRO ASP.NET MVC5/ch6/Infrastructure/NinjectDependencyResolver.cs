using System;
using System.Collections.Generic;
using ch6.Models;
using Ninject;

// 自定义依赖解析器

namespace ch6.Infrastructure {
    public class NinjectDependencyResolver : IDependencyResolver{

    }
}