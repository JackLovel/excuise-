using System.Collections.Generic;
using BooksApi.Models;
using BooksApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace BooksApi.Controllers 
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookController : ControllerBase {
        // 使用　BookService 类执行CRUD操作
        private readonly BookSerivce _bookService;

        public BookController(BookSerivce bookService) {
            _bookService = bookService;
        }

        [HttpGet]
        public ActionResult<List<Book>> Get() {
            return _bookService.Get();
        }

        [HttpGet("{id:length(24)}", Name = "GetBook")]
        public ActionResult<Book> Get(string id) 
        {
            var book = _bookService.Get(id);

            if (book == null) {
                return NotFound();
            }

            return book;
        }

        [HttpPost]
        public ActionResult<Book> Create(Book book) 
        {
            _bookService.Create(book);

            return CreatedAtAction("GetBook", new { id = book.Id.ToString()}, book);
        }        

        [HttpPut("{id:length(24)}")]
        public IActionResult Update(string id, Book bookIn) 
        {
            var book = _bookService.Get(id);

            if (book == null) {
                return NotFound();
            }

            _bookService.Update(id, bookIn);

            return NoContent();
        }

         [HttpDelete("{id:length(24)}")]
        public IActionResult Delete(string id) 
        {
            var book = _bookService.Get(id);

            if (book == null) {
                return NotFound();
            }

            _bookService.Remove(book.Id);

            return NoContent();
        }
    }
}