### MvcMusic (MVC版本)
> 原代码地址    

[教程](https://docs.microsoft.com/zh-cn/aspnet/core/tutorials/first-mvc-app/?view=aspnetcore-2.2) | [github 代码](https://github.com/aspnet/AspNetCore.Docs/tree/master/aspnetcore/tutorials/first-mvc-app/start-mvc/sample)

> 注意事项　　　　
- sqlite 有新的字段添加时，使用工具进行手动添加.
