#!/bin/bash

tar --exclude *.txt -cvf arch.tar * 
